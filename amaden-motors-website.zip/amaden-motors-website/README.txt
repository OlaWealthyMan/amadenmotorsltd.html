AMADEN MOTORS LTD WEBSITE

Files:
- index.html — complete responsive one-page website.

Notes:
- Business details used in this draft were based on public listings found for Amaden Motors Ltd:
  Plot 1335, Suite B2, Amaden Plaza, Mabushi District, Abuja, Nigeria
  Phone: +234 803 320 0275
- The vehicle cards are SAMPLE listings. Replace them with the dealership's actual inventory, prices, mileage and photos before publishing.
- The site uses externally hosted stock photography from Unsplash for the draft visuals.
- WhatsApp enquiry buttons are configured for +234 803 320 0275.

Recommended production additions:
1. Real logo and brand colours.
2. Actual vehicle inventory with admin/CMS.
3. Individual vehicle detail pages.
4. Google Maps location embed.
5. Customer testimonials/reviews.
6. Finance/trade-in/vehicle sourcing pages if offered.
7. SEO, analytics, domain, hosting and SSL.
